'use client';
import { motion } from 'framer-motion';

const slides = [
  {
    title: 'SubSmart',
    subtitle: 'A nova era das substituições no futebol',
    description: 'Conectando banco de reservas, arbitragem e transmissão — em tempo real.'
  },
  {
    title: 'O Problema Atual',
    description: 'Substituições no futebol ainda vivem em 1998. Processo manual, com papel, placas e falhas de comunicação.'
  },
  {
    title: 'A Solução',
    description: 'SubSmart – substituições digitais, rápidas e integradas. App, integração com arbitragem e geração de dados.'
  },
  {
    title: 'Métricas do Sistema',
    description: 'Substituição em até 64s, redução de erros, e meta de 80% dos clubes até a temporada X.'
  },
  {
    title: 'KPIs de Sucesso',
    description: 'Menos erros, mais dados, mais engajamento. Adoção por clubes e federações.'
  },
  {
    title: 'SubSmart está pronto',
    description: 'Tecnologia e paixão pelo futebol, agora jogando no mesmo time.'
  }
];

export default function SubSmartPitchDeckAnimated() {
  return (
    <main className="min-h-screen bg-white flex items-center justify-center p-6">
      <div className="w-full max-w-4xl space-y-10">
        {slides.map((slide, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            className="bg-gray-100 p-8 rounded-2xl shadow-xl"
          >
            <h2 className="text-3xl font-bold text-gray-800 mb-2">{slide.title}</h2>
            {slide.subtitle && <h3 className="text-xl italic text-gray-600">{slide.subtitle}</h3>}
            <p className="text-gray-700 mt-4">{slide.description}</p>
          </motion.div>
        ))}
      </div>
    </main>
  );
}